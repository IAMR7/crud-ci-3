</body>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap/dist/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/jquery/jquery.min.js"></script>
</html>